AFRIKOIN — Release AAB Signing & CI Workflow
============================================

This kit gives you:
1) gradle.properties tuning for faster/safer builds
2) app/build.gradle.kts signingConfigs + buildTypes snippet
3) A GitHub Actions workflow that builds a signed app-release.aab

---
LOCAL BUILD (Android Studio)
----------------------------
1. Put your keystore (.jks) at: .github/keystore/afrikoin-release-key.jks
2. In Android Studio: Build > Generate Signed Bundle / APK > Android App Bundle
3. Or from CLI:

   On Windows PowerShell:
     $env:STORE_FILE = ".github/keystore/afrikoin-release-key.jks"
     $env:STORE_PASSWORD = "YOUR_STORE_PASSWORD"
     $env:KEY_ALIAS = "afrikoin"
     $env:KEY_PASSWORD = "YOUR_KEY_PASSWORD"
     ./gradlew clean bundleRelease

   The file will be at: app/build/outputs/bundle/release/app-release.aab

---
CI/CD (GitHub Actions)
----------------------
Create these repository secrets:
  - KEYSTORE_BASE64 : base64 of your .jks file
  - STORE_PASSWORD  : keystore password
  - KEY_ALIAS       : key alias (e.g. afrikoin)
  - KEY_PASSWORD    : key alias password

How to get base64 of your JKS (Linux/Mac):
  base64 -w0 afrikoin-release-key.jks > keystore.b64

On Windows (PowerShell):
  [Convert]::ToBase64String([IO.File]::ReadAllBytes("afrikoin-release-key.jks")) > keystore.b64

Paste the content of keystore.b64 into the KEYSTORE_BASE64 secret.

Trigger the workflow (Actions > Android Release AAB > Run workflow).
Download the artifact: app-release-aab

---
VERIFY CERT FINGERPRINTS
------------------------
To print SHA-1 and SHA-256 of your upload key:

  keytool -list -v -keystore afrikoin-release-key.jks -alias afrikoin

Compare with the Play Console expected fingerprints to avoid key mismatch.

---
NOTES
-----
- You cannot convert a debug AAB into a Play-ready release. You must rebuild the release variant.
- Make sure your app/build.gradle(.kts) has `isDebuggable = false` in the release build type.
- If you use Google Play App Signing, you still need to SIGN the AAB with your UPLOAD key.
