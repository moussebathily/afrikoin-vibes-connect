# Politique de confidentialité – AfriKoin

Ce dépôt contient la page de politique de confidentialité pour le site **AfriKoin.online**.

## 🔧 Déploiement avec Vercel

1. Fork ou clone ce dépôt
2. Connecte-le à ton compte Vercel
3. Clique sur **Deploy**
4. Ajoute le domaine personnalisé `afrikoin.online`
5. La page sera accessible via :
   - `https://afrikoin.online/politique-confidentialite`
   - ou `https://<your-vercel>.vercel.app/politique-confidentialite`

## 👤 Contact

Pour toute demande liée à la confidentialité, contactez :  
📧 contact@afrikoin.online
