# Android • Build & Publish (Production on Any Branch)

Ce workflow publie **directement en production** sur Google Play **à chaque push sur n'importe quelle branche**.

## Prérequis
- Plugin **Gradle Play Publisher** dans `app/` (version conseillée `3.9.1`).
- Secrets GitHub : `PLAY_SERVICE_ACCOUNT_JSON`, `ANDROID_KEYSTORE_BASE64`, `ANDROID_KEYSTORE_PASSWORD`, `ANDROID_KEY_PASSWORD`, `ANDROID_KEY_ALIAS`.
- Accès **Release Manager** pour le compte de service sur ton app.

## Déclenchement
- **push** sur **toutes** les branches → build `.aab` + **publication en production (completed)**.

⚠️ **Attention** : publier depuis toutes les branches est risqué. Utilise des protections de branches, revues obligatoires, ou passe par un repo *staging*.

## Notes
- Tu peux passer des **notes de version** via “Run workflow” → `release_notes`.
- Le `.aab` est aussi conservé en **artifact** du job.
