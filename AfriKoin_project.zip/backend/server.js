const express = require('express');
const { RtcTokenBuilder, RtcRole } = require('agora-access-token');

const APP_ID = process.env.APP_ID || 'TON_AGORA_APP_ID';
const APP_CERTIFICATE = process.env.APP_CERTIFICATE || 'TON_AGORA_APP_CERTIFICATE';

const app = express();
const PORT = process.env.PORT || 3000;

app.get('/token', (req, res) => {
  const channelName = req.query.channelName;
  if (!channelName) {
    return res.status(400).json({ error: 'channelName est requis' });
  }
  const uid = req.query.uid ? parseInt(req.query.uid, 10) : 0;
  const role = RtcRole.PUBLISHER;
  const expirationTimeInSeconds = 3600; // 1h
  const currentTimestamp = Math.floor(Date.now() / 1000);
  const privilegeExpiredTs = currentTimestamp + expirationTimeInSeconds;

  const token = RtcTokenBuilder.buildTokenWithUid(
    APP_ID,
    APP_CERTIFICATE,
    channelName,
    uid,
    role,
    privilegeExpiredTs
  );

  res.json({ token });
});

app.listen(PORT, () => {
  console.log(`Serveur token Agora lancé sur http://localhost:${PORT}`);
});