import React, { useState, useEffect } from 'react';
import { View, Text, Button, StyleSheet, Platform } from 'react-native';
import RtcEngine from 'react-native-agora';
import { request, PERMISSIONS } from 'react-native-permissions';

const APP_ID = 'TON_AGORA_APP_ID';
const CHANNEL_NAME = 'afrikoin_live';
const TOKEN_SERVER_URL = 'http://localhost:3000/token'; // Mettre l'URL publique de ton backend

export default function App() {
  const [engine, setEngine] = useState(null);
  const [joined, setJoined] = useState(false);

  useEffect(() => {
    (async () => {
      if (Platform.OS === 'android') {
        await request(PERMISSIONS.ANDROID.CAMERA);
        await request(PERMISSIONS.ANDROID.RECORD_AUDIO);
      }
      const rtcEngine = await RtcEngine.create(APP_ID);
      await rtcEngine.enableVideo();
      rtcEngine.addListener('JoinChannelSuccess', () => setJoined(true));
      rtcEngine.addListener('LeaveChannel', () => setJoined(false));
      setEngine(rtcEngine);
    })();

    return () => {
      engine?.destroy();
    };
  }, []);

  async function fetchToken(channelName) {
    try {
      const res = await fetch(`${TOKEN_SERVER_URL}?channelName=${channelName}&uid=0`);
      const data = await res.json();
      return data.token;
    } catch (e) {
      console.error('Erreur fetch token:', e);
      return null;
    }
  }

  async function startLive() {
    if (!engine) return;
    const token = await fetchToken(CHANNEL_NAME);
    await engine.joinChannel(token, CHANNEL_NAME, null, 0);
  }

  async function endLive() {
    if (!engine) return;
    await engine.leaveChannel();
  }

  return (
    <View style={styles.container}>
      {!joined ? (
        <>
          <Button title="Lancer le live" onPress={startLive} />
        </>
      ) : (
        <>
          <Text style={styles.text}>🔴 Live en cours</Text>
          <Button title="Terminer le live" onPress={endLive} />
        </>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  text: { fontSize: 18, margin: 10 },
});