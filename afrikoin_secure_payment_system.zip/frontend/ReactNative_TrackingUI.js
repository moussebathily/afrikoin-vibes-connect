// React Native - UI de suivi de colis avec confirmation
import React from 'react';
import { View, Text, Button, Image } from 'react-native';

const TrackingScreen = ({ delivery, onConfirm }) => {
  return (
    <View style={{ padding: 20 }}>
      <Text>Colis livré à : {delivery.address}</Text>
      <Text>État : {delivery.status}</Text>
      {delivery.photoUrl && <Image source={{ uri: delivery.photoUrl }} style={{ width: 200, height: 200 }} />}
      {delivery.status === 'livré' && (
        <Button title="J'ai reçu le colis" onPress={onConfirm} />
      )}
    </View>
  );
};

export default TrackingScreen;