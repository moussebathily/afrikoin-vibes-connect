# Déploiement page Suivi Sécurisé AfriKoin

## Sur le site web (Next.js)

- Copier le dossier `public/qr_codes/` dans la racine `public/` du projet Next.js.
- Copier le fichier `pages/suivi-securise.tsx` dans `pages/`.
- Copier `components/SecurePaymentButton.tsx` dans `components/`.
- Ajouter `<SecurePaymentButton />` dans la barre de navigation principale.
- Déployer via GitHub + Vercel.

## Sur l’application mobile (React Native)

- Copier `AppWebViewScreen.tsx` dans le dossier des écrans.
- Ajouter une route React Navigation vers `AppWebViewScreen`.
- Ajouter un bouton menu ou lien vers ce nouvel écran.
- Tester sur Android / iOS.

## Test QR Codes

- Les QR codes sont accessibles via :
  - https://afrikoin.com/qr_codes/stripe_escrow_docs.png
  - https://afrikoin.com/qr_codes/afrikoin_app.png
  - https://afrikoin.com/qr_codes/conditions_générales_pdf.png

Merci de tester la navigation et le scan QR.