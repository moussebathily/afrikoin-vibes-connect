// AppWebViewScreen.tsx
import React from 'react';
import { View, StyleSheet } from 'react-native';
import { WebView } from 'react-native-webview';

const AppWebViewScreen = () => {
  return (
    <View style={styles.container}>
      <WebView source={{ uri: 'https://afrikoin.com/suivi-securise' }} />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
});

export default AppWebViewScreen;