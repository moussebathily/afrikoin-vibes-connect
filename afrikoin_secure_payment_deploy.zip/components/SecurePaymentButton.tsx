// components/SecurePaymentButton.tsx
import React from 'react';
import { useRouter } from 'next/router';

export default function SecurePaymentButton() {
  const router = useRouter();
  return (
    <button
      onClick={() => router.push('/suivi-securise')}
      style={{
        padding: '0.5rem 1rem',
        backgroundColor: '#2563eb',
        color: 'white',
        borderRadius: 8,
        border: 'none',
        cursor: 'pointer',
        fontWeight: 'bold',
        marginLeft: 10
      }}
      aria-label="Accéder au paiement sécurisé"
    >
      Paiement sécurisé
    </button>
  );
}