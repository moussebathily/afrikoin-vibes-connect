import Head from 'next/head';
import Image from 'next/image';

export default function SuiviSecurise() {
  return (
    <div className="min-h-screen bg-gray-50 py-8 px-4">
      <Head>
        <title>Suivi Sécurisé – AfriKoin</title>
      </Head>
      <h1 className="text-2xl font-bold text-center text-gray-800 mb-4">Suivi Sécurisé – AfriKoin</h1>
      <p className="text-center text-gray-600 max-w-md mx-auto mb-8">
        Scannez ces QR codes pour accéder aux liens de paiement sécurisé, application et CGV.
      </p>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 justify-center items-center">
        <div className="bg-white rounded-2xl shadow p-4 flex flex-col items-center">
          <Image src="/qr_codes/stripe_escrow_docs.png" width={200} height={200} alt="Stripe Escrow" />
          <p className="mt-2 font-medium text-gray-700">Stripe Escrow</p>
        </div>
        <div className="bg-white rounded-2xl shadow p-4 flex flex-col items-center">
          <Image src="/qr_codes/afrikoin_app.png" width={200} height={200} alt="AfriKoin App" />
          <p className="mt-2 font-medium text-gray-700">AfriKoin App</p>
        </div>
        <div className="bg-white rounded-2xl shadow p-4 flex flex-col items-center">
          <Image src="/qr_codes/conditions_générales_pdf.png" width={200} height={200} alt="Conditions Générales" />
          <p className="mt-2 font-medium text-gray-700">Conditions Générales</p>
        </div>
      </div>
    </div>
  );
}