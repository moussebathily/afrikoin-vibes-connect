
package com.afrikoin.ui

import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import org.junit.Rule
import org.junit.Test

class WelcomeScreenNavigationTest {

    @get:Rule
    val composeTestRule = createComposeRule()

    @Test
    fun welcomeScreen_navigatesToSecondScreen_onNextClick() {
        composeTestRule.setContent {
            MainNavigation()
        }

        composeTestRule.onNodeWithText("Bienvenue sur AfriKoin")
            .assertIsDisplayed()

        composeTestRule.onNodeWithText("Suivant")
            .performClick()

        composeTestRule.onNodeWithText("Écran suivant")
            .assertIsDisplayed()
    }
}
