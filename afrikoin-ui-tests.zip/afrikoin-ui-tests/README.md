
# Afrikoin UI Tests (Jetpack Compose)

Ce dépôt contient une démo de test UI automatisé pour Android avec Jetpack Compose, incluant la navigation entre deux écrans.

## Structure

- `WelcomeScreen.kt` : écran d'accueil avec bouton "Suivant"
- `SecondScreen.kt` : écran affiché après clic
- `MainNavigation.kt` : gestion de la navigation Compose
- `WelcomeScreenNavigationTest.kt` : test UI complet

## Lancer les tests

```bash
./gradlew connectedAndroidTest
```

---
Mousse Bathily – 2025
