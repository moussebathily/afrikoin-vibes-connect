
package com.afrikoin.ui

import androidx.compose.runtime.Composable
import androidx.navigation.compose.*
import androidx.navigation.NavHostController

@Composable
fun MainNavigation() {
    val navController = rememberNavController()
    AppNavHost(navController)
}

@Composable
fun AppNavHost(navController: NavHostController) {
    NavHost(navController, startDestination = "welcome") {
        composable("welcome") {
            WelcomeScreen(onNextClick = {
                navController.navigate("second")
            })
        }
        composable("second") {
            SecondScreen()
        }
    }
}
