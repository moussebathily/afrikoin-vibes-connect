#!/bin/bash
# 🔧 Script de correction automatique pour AndroidManifest et build.gradle
# Auteur : Mousse Bathily x GPT-5
# Projet : afrikoin-vibes-connect

set -e

echo "🚀 Démarrage du correcteur automatique Android..."

MANIFEST_PATH="app/src/main/AndroidManifest.xml"
GRADLE_PATH="app/build.gradle"

# 1️⃣ Supprimer l’attribut package dans AndroidManifest.xml
if grep -q 'package=' "$MANIFEST_PATH"; then
  echo "🧹 Suppression de l’attribut package dans AndroidManifest.xml..."
  sed -i.bak 's/package="[^"]*"//' "$MANIFEST_PATH"
  echo "✅ AndroidManifest.xml corrigé."
else
  echo "ℹ️ Aucun attribut package trouvé (déjà propre)."
fi

# 2️⃣ Ajouter ou corriger la namespace dans build.gradle
if grep -q 'namespace' "$GRADLE_PATH"; then
  echo "✅ Namespace déjà présent dans build.gradle."
else
  echo "🧩 Ajout de la namespace dans build.gradle..."
  sed -i.bak '/^android {/a \    namespace "com.afrikoin.myapplication"' "$GRADLE_PATH"
  echo "✅ Namespace ajouté : com.afrikoin.myapplication"
fi

# 3️⃣ Nettoyer et reconstruire le projet
echo "🧽 Nettoyage du projet..."
cd android
./gradlew clean

echo "🏗️ Reconstruction du build Debug..."
./gradlew assembleDebug || echo "⚠️ Le build peut échouer si d'autres erreurs subsistent."

echo "🎯 Correction terminée avec succès !"
