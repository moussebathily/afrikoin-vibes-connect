✅ Correction automatique du projet Android AfriKoin Vibes Connect

1️⃣ Le script "fix_android_manifest.sh" supprime l'ancien package obsolète de AndroidManifest.xml
2️⃣ Il ajoute un namespace correct dans app/build.gradle
3️⃣ Le workflow GitHub exécute ce script avant chaque build AAB

👉 Pour tester localement :
   bash fix_android_manifest.sh

👉 Pour déclencher le build automatique :
   git add .
   git commit -m "Fix AndroidManifest + workflow auto"
   git push origin main
