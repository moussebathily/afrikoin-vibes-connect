# Android • Auto publish on every push (Google Play)

This setup publishes your Android app **immediately to production** on **every branch push**.

## Files
- `.github/workflows/android-publish.yml` — CI workflow
- `settings.gradle.kts.root.template` — use if your settings file is at repo root
- `android/settings.gradle.kts.template` — use if your settings file lives under `android/`

## Required GitHub Secrets (repo → Settings → Secrets and variables → Actions)
- `PLAY_SERVICE_ACCOUNT_JSON` — full JSON of your Play service account
- `ANDROID_KEYSTORE_BASE64` — base64 of your upload keystore
- `ANDROID_KEYSTORE_PASSWORD`
- `ANDROID_KEY_PASSWORD`
- `ANDROID_KEY_ALIAS`

## Capacitor settings.gradle.kts
Choose **one** template according to your file location.

**Root (`./settings.gradle.kts`):**
```kotlin
pluginManagement { repositories { gradlePluginPortal(); google(); mavenCentral() } }
dependencyResolutionManagement {
  repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
  repositories { google(); mavenCentral() }
}
apply(from = File("node_modules/@capacitor/android/capacitor.settings.gradle"))
```

**Inside `android/` (`android/settings.gradle.kts`):**
```kotlin
pluginManagement { repositories { gradlePluginPortal(); google(); mavenCentral() } }
dependencyResolutionManagement {
  repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
  repositories { google(); mavenCentral() }
}
apply(from = File("../node_modules/@capacitor/android/capacitor.settings.gradle"))
```

## Notes
- SDK installed for API 34. Set your `compileSdk`/`targetSdk` accordingly.
- Gradle cache is **disabled** to avoid random cache outages blocking the pipeline.
- The workflow also runs on `workflow_dispatch` with optional release notes.
