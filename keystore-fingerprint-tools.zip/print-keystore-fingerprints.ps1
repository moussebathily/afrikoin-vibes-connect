
param(
  [Parameter(Mandatory=$true)][string]$KeystorePath,
  [Parameter(Mandatory=$true)][string]$Alias
)

Write-Host "== Keystore fingerprint check =="
Write-Host "Keystore: $KeystorePath"
Write-Host "Alias   : $Alias"

$storePass = Read-Host -AsSecureString "Enter keystore password"
$plainStorePass = [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR($storePass))

$cmd = "keytool -list -v -keystore `"$KeystorePath`" -alias `"$Alias`" -storepass `"$plainStorePass`""
$raw = cmd /c $cmd 2>&1

if ($LASTEXITCODE -ne 0) { Write-Error $raw; exit 1 }

$sha1   = ($raw | Select-String -Pattern 'SHA1: *([0-9A-F:]*)' -AllMatches).Matches.Value | Select-Object -First 1
$sha256 = ($raw | Select-String -Pattern 'SHA-256: *([0-9A-F:]*)' -AllMatches).Matches.Value | Select-Object -First 1

$sha1Val   = $sha1 -replace 'SHA1: *',''
$sha256Val = $sha256 -replace 'SHA-256: *',''

Write-Host "SHA-1   : $sha1Val"
Write-Host "SHA-256 : $sha256Val"

$expected = "F5:23:19:70:20:C2:5E:7A:33:79:D2:EF:3C:46:8E:AD:AD:FA:0C:26:35:E4:49:D6:B9:3B:F6:CF:84:0F:C1:59"
if ($sha256Val -eq $expected) { 
  Write-Host "✔ MATCH: keystore SHA-256 equals expected Play Console value" 
  exit 0
} else { 
  Write-Warning "✖ MISMATCH: expected: $expected"
  exit 2
}
