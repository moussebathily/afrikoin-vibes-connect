#!/usr/bin/env bash
set -euo pipefail

if [[ $# -lt 2 ]]; then
  echo "Usage: $(basename "$0") <keystore.jks> <alias>"
  exit 1
fi

KS="$1"
ALIAS="$2"

echo "== Keystore fingerprint check =="
echo "Keystore: $KS"
echo "Alias   : $ALIAS"

read -s -p "Enter keystore password: " STOREPASS
echo

RAW=$(keytool -list -v -keystore "$KS" -alias "$ALIAS" -storepass "$STOREPASS" 2>&1 || true)
echo "$RAW" >/dev/stderr

SHA1=$(echo "$RAW" | grep -Eo 'SHA1: *[0-9A-F:]+' | head -n1 | sed 's/.*SHA1: *//')
SHA256=$(echo "$RAW" | grep -Eo 'SHA-256: *[0-9A-F:]+' | head -n1 | sed 's/.*SHA-256: *//')

echo "SHA-1   : $SHA1"
echo "SHA-256 : $SHA256"

EXPECTED="F5:23:19:70:20:C2:5E:7A:33:79:D2:EF:3C:46:8E:AD:AD:FA:0C:26:35:E4:49:D6:B9:3B:F6:CF:84:0F:C1:59"
if [[ "$SHA256" == "$EXPECTED" ]]; then
  echo "✔ MATCH: keystore SHA-256 equals expected Play Console value"
  exit 0
else
  echo "✖ MISMATCH: expected: $EXPECTED" >&2
  exit 2
fi
