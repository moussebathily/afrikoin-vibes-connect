# AfriKoin Auto-Updater (IA)

Ce système permet de générer tous les 3 mois une nouvelle fonctionnalité dans l’app AfriKoin de manière semi-automatique grâce à l’IA (OpenAI GPT-4o) + GitHub Actions.

## Structure
- `scripts/` : scripts de génération et commit
- `.github/workflows/` : automatisation via GitHub Actions
- `example-output/` : exemple de fonctionnalité
- `.env.example` : variables nécessaires

## Pré-requis
- Clé OpenAI : `OPENAI_API_KEY`
- Token GitHub CLI : `GITHUB_TOKEN`

## Déploiement
1. Copier dans votre dépôt `afrikoin-app`
2. Configurer les secrets GitHub
3. Activer le workflow planifié
