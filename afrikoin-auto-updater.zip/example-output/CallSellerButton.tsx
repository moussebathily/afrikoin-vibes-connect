import { Linking, Button } from 'react-native';

export default function CallSellerButton({ phoneNumber }: { phoneNumber: string }) {
  return (
    <Button title="Appeler le vendeur" onPress={() => Linking.openURL(`tel:${phoneNumber}`)} />
  );
}
