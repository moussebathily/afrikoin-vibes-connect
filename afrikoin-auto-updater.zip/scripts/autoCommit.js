import { execSync } from "child_process";

const branchName = `feature/auto-${Date.now()}`;

try {
  execSync(`git checkout -b ${branchName}`);
  execSync("git add .");
  execSync('git commit -m "feat(auto): nouvelle fonctionnalité générée par l’IA"');
  execSync(`git push origin ${branchName}`);
  execSync(`gh pr create --base main --head ${branchName} --title "Nouvelle fonctionnalité IA" --body "Ajout automatique d'une nouvelle fonctionnalité."`);
  console.log("Pull request créée avec succès.");
} catch (error) {
  console.error("Erreur :", error);
}
