import { Configuration, OpenAIApi } from "openai";
import fs from "fs";
import dotenv from "dotenv";
dotenv.config();

const configuration = new Configuration({
  apiKey: process.env.OPENAI_API_KEY,
});
const openai = new OpenAIApi(configuration);

async function generateFeature() {
  const prompt = fs.readFileSync("scripts/featurePrompt.txt", "utf8");
  const response = await openai.createChatCompletion({
    model: "gpt-4o",
    messages: [
      { role: "system", content: "Tu es un assistant développeur React Native spécialisé en marketplace mobile." },
      { role: "user", content: prompt }
    ],
  });

  const result = response.data.choices[0].message.content;
  fs.writeFileSync("example-output/GeneratedFeature.tsx", result);
  console.log("Feature générée avec succès.");
}

generateFeature();
