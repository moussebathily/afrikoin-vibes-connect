# 🚀 Déploiement Afrikoin

## Secrets GitHub à configurer
- ANDROID_KEYSTORE_BASE64
- ANDROID_KEYSTORE_PASSWORD
- ANDROID_KEY_ALIAS
- ANDROID_KEY_PASSWORD
- PLAY_SERVICE_ACCOUNT_JSON
- VERCEL_TOKEN
- ORG_ID
- PROJECT_ID

## Lancer le déploiement
- Pousser n’importe quelle branche → déploiement automatique
- Publie sur Google Play **100 % production**
- Déploie le site sur Vercel

## Badge
![Déploiement Afrikoin](https://github.com/<TON-UTILISATEUR>/<TON-DEPOT>/actions/workflows/deploy-afrikoin.yml/badge.svg)
