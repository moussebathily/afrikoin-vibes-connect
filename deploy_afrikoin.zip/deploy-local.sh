#!/bin/bash
set -e

echo "🚀 Building AAB locally..."
cd android
./gradlew bundleRelease

echo "📤 Uploading to Google Play..."
npx @google/play-cli upload --track production   --package com.afrikoin.myapplication   --aab android/app/build/outputs/bundle/release/app-release.aab

echo "✅ Done"
