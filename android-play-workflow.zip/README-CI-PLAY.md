# Android • Build & Publish to Google Play (CI/CD)

Ce workflow GitHub Actions génère automatiquement un AAB signé et le publie sur Google Play via Gradle Play Publisher (GPP).
Il permet aussi de pousser sur un track (internal/alpha/beta/production) et de choisir le statut (draft/inProgress/halted/completed).

---

## 1) Pré-requis côté Play Console
1. Active Play App Signing (recommandé).
2. Va dans API access → Link project (si nécessaire).
3. Create service account dans Google Cloud, puis Grant access dans Play Console avec le rôle Release Manager et l'accès à ton app.
4. Télécharge le JSON du compte de service.

---

## 2) Secrets à ajouter dans GitHub (Settings → Secrets and variables → Actions)
- PLAY_SERVICE_ACCOUNT_JSON : contenu complet du fichier JSON (copier-coller le texte).
- ANDROID_KEYSTORE_BASE64 : ton fichier .jks encodé en base64 (clé d’upload si Play App Signing est activé).
- ANDROID_KEYSTORE_PASSWORD : password du keystore.
- ANDROID_KEY_PASSWORD : password de la clé.
- ANDROID_KEY_ALIAS : alias de la clé.

Pour encoder le keystore en base64 (Linux/Mac) :
base64 -w 0 afrikoin-release-key.jks > keystore.b64
Windows (PowerShell) : [System.Convert]::ToBase64String([IO.File]::ReadAllBytes("afrikoin-release-key.jks")) > keystore.b64

---

## 3) Ajouter le plugin Gradle Play Publisher dans le module :app
app/build.gradle (Groovy) :
plugins {
    id 'com.android.application'
    id 'com.github.triplet.play' version '3.9.1' // ou la dernière version stable
}

app/build.gradle.kts (Kotlin DSL) :
plugins {
    id("com.android.application")
    id("com.github.triplet.play") version "3.9.1" // ou la dernière version stable
}

Aucune config obligatoire dans le code : les paramètres Play sont passés par -P dans le workflow.

### Signature release (exemple Gradle Groovy)
android {
  signingConfigs {
    release {
      storeFile file(System.getenv("HOME") + "/release.keystore")
      storePassword project.findProperty("RELEASE_STORE_PASSWORD")
      keyAlias project.findProperty("RELEASE_KEY_ALIAS")
      keyPassword project.findProperty("RELEASE_KEY_PASSWORD")
    }
  }
  buildTypes {
    release {
      signingConfig signingConfigs.release
      minifyEnabled false
    }
  }
}

---

## 4) Lancer la publication
- Automatique sur push vers main ou tag v*
- Manuel via Actions → Run workflow en choisissant track et release_status

Le job construit le .aab puis lance :
./gradlew publishReleaseBundle -Pplay.serviceAccountCredentials=$HOME/play-account.json -Pplay.track=internal -Pplay.releaseStatus=draft

---

## 5) Dépannage rapide
- Mauvaise clé d’upload : l’empreinte SHA-1 du certificat d’upload doit correspondre à celle enregistrée dans Play Console (App Integrity).
- Permissions : assure-toi que le service account a le rôle Release Manager et l’accès à l’app.
- Nom du package : il doit être identique à celui déclaré sur Play (applicationId dans app/build.gradle).
