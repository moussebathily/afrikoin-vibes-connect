#!/bin/bash

# 📦 Script de build automatique pour .aab (Android App Bundle)

echo "📦 Démarrage du build .aab..."

# Nettoyer les builds précédents
./gradlew clean

# Générer le .aab pour la version release
./gradlew bundleRelease

# Afficher le chemin final
AAB_PATH="app/build/outputs/bundle/release/app-release.aab"

if [ -f "$AAB_PATH" ]; then
    echo "✅ Build réussi :"
    echo "$AAB_PATH"
else
    echo "❌ Le fichier .aab n'a pas été généré."
    exit 1
fi
