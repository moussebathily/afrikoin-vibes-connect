# GROOVY (app/build.gradle)
android {
  signingConfigs {
    release {
      storeFile file(System.getenv("RELEASE_STORE_FILE") ?: RELEASE_STORE_FILE)
      storePassword System.getenv("RELEASE_STORE_PASSWORD") ?: RELEASE_STORE_PASSWORD
      keyAlias System.getenv("RELEASE_KEY_ALIAS") ?: RELEASE_KEY_ALIAS
      keyPassword System.getenv("RELEASE_KEY_PASSWORD") ?: RELEASE_KEY_PASSWORD
    }
  }
  buildTypes {
    release {
      minifyEnabled true
      shrinkResources true
      signingConfig signingConfigs.release
    }
  }
}

# KOTLIN DSL (app/build.gradle.kts)
android {
  signingConfigs {
    create("release") {
      storeFile = file(System.getenv("RELEASE_STORE_FILE") ?: providers.gradleProperty("RELEASE_STORE_FILE").get())
      storePassword = System.getenv("RELEASE_STORE_PASSWORD") ?: providers.gradleProperty("RELEASE_STORE_PASSWORD").get()
      keyAlias = System.getenv("RELEASE_KEY_ALIAS") ?: providers.gradleProperty("RELEASE_KEY_ALIAS").get()
      keyPassword = System.getenv("RELEASE_KEY_PASSWORD") ?: providers.gradleProperty("RELEASE_KEY_PASSWORD").get()
    }
  }
  buildTypes {
    getByName("release") {
      isMinifyEnabled = true
      isShrinkResources = true
      signingConfig = signingConfigs.getByName("release")
    }
  }
}
