# Pack CI — Android (Capacitor) → Google Play

## Contenu
- `.github/workflows/publish_google_play.yml` — build AAB + publication (production), rollout progressif optionnel.
- `settings.gradle.kts.root.template` — si le fichier est **à la racine**.
- `android/settings.gradle.kts.template` — si le fichier est **dans `android/`**.
- `SIGNING-GRADLE-BLOCKS.md` — blocs `signingConfigs` prêts (Groovy/Kotlin).

## Secrets requis (GitHub → Settings → Secrets and variables → Actions)
- `PLAY_SERVICE_ACCOUNT_JSON` — contenu JSON **complet** du compte de service Play.
- `ANDROID_KEYSTORE_BASE64` — keystore encodé base64.
- `ANDROID_KEYSTORE_PASSWORD`
- `ANDROID_KEY_PASSWORD`
- `ANDROID_KEY_ALIAS`

Encoder le keystore :
```bash
base64 -w 0 release.keystore > keystore.b64
```

## Déclenchement
- Push d’un tag `v*` (ex. `v1.3.0`) — build + publish.
- Ou manuel via l’onglet *Actions* (entrées: `release_notes`, `rollout_fraction`).

## Chemins Capacitor dans `settings.gradle.kts`
- **Racine** :
```kotlin
apply(from = File("node_modules/@capacitor/android/capacitor.settings.gradle"))
```
- **Dans `android/`** :
```kotlin
apply(from = File("../node_modules/@capacitor/android/capacitor.settings.gradle"))
```

## Exigences
- `compileSdk`/`targetSdk` = 34 (adapter si vous voulez 35).
- Plugin **Gradle Play Publisher** appliqué dans le module `app` :
```kotlin
plugins {
  id("com.android.application")
  id("com.github.triplet.play") version "3.9.1"
}
```
