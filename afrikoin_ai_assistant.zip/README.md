# Composant IA Assistant – AfriKoin

Contenu :
- `IAssistantPreview.tsx` : composant React (Next.js/React)
- `mock-ai-banner.jpg` : aperçu généré (à remplacer par IA réelle)
- Dossier prêt à intégrer dans `afrikoin-web`

Étapes :
1. Copier le fichier dans `/components`
2. Afficher dans la page de création d'annonce avec : <IAssistantPreview />
3. Connecter à une API IA réelle pour contenu, image et QR code