import React, { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { ImagePlus, Sparkles, ScanEye } from 'lucide-react';

export default function IAssistantPreview() {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [suggestedTitle, setSuggestedTitle] = useState('');
  const [suggestedDesc, setSuggestedDesc] = useState('');
  const [previewUrl, setPreviewUrl] = useState('');

  const handleAIEnhance = async () => {
    setSuggestedTitle('Chaussures en cuir élégantes pour homme - Taille 44');
    setSuggestedDesc('Découvrez ces magnifiques chaussures en cuir, idéales pour les grandes occasions. Confortables, résistantes et à prix abordable.');
    setPreviewUrl('/ai/previews/mock-ai-banner.jpg');
  };

  return (
    <Card className="p-4 mt-6 shadow-xl">
      <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
        <Sparkles size={20} className="text-blue-500" /> Assistance IA – Améliorez votre annonce
      </h2>

      <div className="space-y-3">
        <label className="block font-medium">Titre de votre annonce :</label>
        <Input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Ex: Chaussures homme neuves" />

        <label className="block font-medium">Description :</label>
        <Textarea value={description} onChange={(e) => setDescription(e.target.value)} placeholder="Ajoutez plus de détails..." />

        <Button onClick={handleAIEnhance} className="mt-3">✨ Demander suggestions IA</Button>

        {suggestedTitle && (
          <div className="mt-4">
            <p className="font-semibold text-green-600">✅ Titre suggéré :</p>
            <p className="text-gray-800">{suggestedTitle}</p>

            <p className="font-semibold text-green-600 mt-2">✅ Description suggérée :</p>
            <p className="text-gray-800 whitespace-pre-line">{suggestedDesc}</p>
          </div>
        )}

        {previewUrl && (
          <div className="mt-6 text-center">
            <p className="font-semibold text-blue-500 mb-2">🎨 Miniature générée :</p>
            <img src={previewUrl} alt="preview" className="rounded-xl shadow border mx-auto max-w-xs" />
          </div>
        )}
      </div>
    </Card>
  );
}