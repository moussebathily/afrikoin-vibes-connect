// Exemple Node.js simplifié avec Stripe (Escrow)
const stripe = require('stripe')('sk_test_your_key_here');

async function createEscrowPayment(customerId, amount, currency = 'eur') {
  const paymentIntent = await stripe.paymentIntents.create({
    amount,
    currency,
    customer: customerId,
    capture_method: 'manual', // Important pour escrow
  });
  return paymentIntent;
}

async function confirmDelivery(paymentIntentId) {
  await stripe.paymentIntents.capture(paymentIntentId); // Libère le paiement
}

module.exports = { createEscrowPayment, confirmDelivery };