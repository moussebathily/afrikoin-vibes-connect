# Android • Build & Auto-Publish (Best Practice)

**Ce preset choisit les “meilleurs” réglages par défaut :**
- **Push sur `main` →** publication **sécurisée** sur `internal` en **draft** (rien de public par erreur).
- **Tag `v*` (ex: `v1.2.3`) →** publication **production** en **completed** (mise en ligne directe).

Tu peux toujours **surcharger** manuellement quand tu lances “Run workflow” :
- `track` : internal / alpha / beta / production
- `release_status` : draft / inProgress / halted / completed

---

## Secrets à configurer (GitHub → Settings → Secrets and variables → Actions)
- `PLAY_SERVICE_ACCOUNT_JSON` : contenu complet du JSON du service account (API Google Play) avec rôle **Release Manager** et accès à l’app.
- `ANDROID_KEYSTORE_BASE64` : ton fichier `.jks` d’upload **encodé base64**.
- `ANDROID_KEYSTORE_PASSWORD` : mot de passe du keystore.
- `ANDROID_KEY_PASSWORD` : mot de passe de la clé.
- `ANDROID_KEY_ALIAS` : alias de la clé.

> Encodage base64 (Linux/Mac) : `base64 -w 0 afrikoin-release-key.jks > keystore.b64`  
> Windows (PowerShell) : `[Convert]::ToBase64String([IO.File]::ReadAllBytes("afrikoin-release-key.jks"))`

---

## Plugin Gradle Play Publisher dans `app/`
**Groovy (`app/build.gradle`)**
```groovy
plugins {
  id 'com.android.application'
  id 'com.github.triplet.play' version '3.9.1'
}
```

**Kotlin DSL (`app/build.gradle.kts`)**
```kotlin
plugins {
  id("com.android.application")
  id("com.github.triplet.play") version "3.9.1"
}
```

> Aucune autre config n’est obligatoire : le workflow passe les paramètres à Gradle via `-P`.

### Signature release (exemple Groovy)
```groovy
android {
  signingConfigs {
    release {
      storeFile file(System.getenv("HOME") + "/release.keystore")
      storePassword project.findProperty("RELEASE_STORE_PASSWORD")
      keyAlias project.findProperty("RELEASE_KEY_ALIAS")
      keyPassword project.findProperty("RELEASE_KEY_PASSWORD")
    }
  }
  buildTypes {
    release {
      signingConfig signingConfigs.release
      minifyEnabled false
    }
  }
}
```

---

## Comment ça marche
1. **Push** sur `main` → build AAB + upload en **artifact** + **publish** sur `internal` en **draft**.
2. **Tag** `v1.2.3` → build AAB + artifact + **publish** en **production** **completed** (direct live).
3. **Actions → Run workflow** → tu peux choisir un autre track/status au besoin.

---

## Dépannage rapide
- **Clé d’upload** : assure-toi que la SHA‑1 correspond à celle de *App Integrity* (Play Console).
- **Permissions API** : le service account doit avoir **Release Manager** et l’**accès à l’app** (Play Console → Users & permissions).
- **applicationId** : doit correspondre exactement au package publié.

---

Bon déploiement 🚀
